import { S3Client, ListObjectsV2Command } from "@aws-sdk/client-s3";

const s3Client = new S3Client({ region: "us-east-2" }); // Specify your region

export const handler = async () => {
    const bucketName = "cfbh-logos";

    try {
        const command = new ListObjectsV2Command({ Bucket: bucketName });
        const response = await s3Client.send(command);

        const imageUrls = response.Contents.map(object =>
            `https://${bucketName}.s3.amazonaws.com/${object.Key}`
        );

        return {
            statusCode: 200,
            body: JSON.stringify({ imageUrls }),
        };
    } catch (error) {
        console.error("Error:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message }),
        };
    }
};
